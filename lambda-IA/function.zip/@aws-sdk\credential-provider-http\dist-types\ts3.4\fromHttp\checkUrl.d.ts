import { Logger } from "@smithy/types";
export declare const checkUrl: (url: URL, logger?: Logger) => void;
