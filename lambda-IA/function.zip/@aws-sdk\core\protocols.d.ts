/**
 * Do not edit:
 * This is a compatibility redirect for contexts that do not understand package.json exports field.
 */
declare module "@aws-sdk/core/protocols" {
  export * from "@aws-sdk/core/dist-types/submodules/protocols/index.d";
}
