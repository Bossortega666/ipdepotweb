export declare const getUpdatedSystemClockOffset: (
  clockTime: string,
  currentSystemClockOffset: number
) => number;
