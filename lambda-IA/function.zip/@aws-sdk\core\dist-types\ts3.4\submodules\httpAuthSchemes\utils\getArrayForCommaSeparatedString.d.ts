export declare const getArrayForCommaSeparatedString: (str: string) => string[];
