export declare const getSkewCorrectedDate: (systemClockOffset: number) => Date;
