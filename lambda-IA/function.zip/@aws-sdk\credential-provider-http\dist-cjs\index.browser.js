"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fromHttp = void 0;
var fromHttp_browser_1 = require("./fromHttp/fromHttp.browser");
Object.defineProperty(exports, "fromHttp", { enumerable: true, get: function () { return fromHttp_browser_1.fromHttp; } });
